import tkinter as tk
from PIL import ImageTk, Image
from tkinter import font
import pandas as pd
from scipy.spatial import distance
import numpy as np
from sklearn.preprocessing import StandardScaler

Clusters = pd.read_csv('clusterInfo_14.csv')
Clusters = Clusters.loc[:, ~Clusters.columns.str.contains('unnamed', case=False)]   
clusters_3 = pd.read_csv('3_clusters.csv')    
HEIGHT = 600 #700 pixels
WIDTH  = 700

root = tk.Tk()
root.title('Anomaly Detector Demo')
root.iconbitmap('D:\\Python\\Ideas\\tamuq_ecen.png')
# root.geometry('800x800')

# root = tk.Tk() #root window to place everything into

# This function is to calculate the anomaly 
def anomaly_values(user_input,inputs):
    
    scaler = StandardScaler()
    columns = list(clusters_3.columns)
    listofzeros = [0]*len(columns)
    msgs_df = dict(zip(columns,listofzeros))
    msgs_df = pd.DataFrame(msgs_df,index=[0])
    scaler.fit(clusters_3.values)
    Anom_data = scaler.transform(msgs_df.values)

    jaccard_distances = []
    Cluster_array = Clusters.values
    # comparing the jaccard distances of the input with each of the 14 centroids to see which cluster it could/could not belong to
    for i in range(len(Clusters)):
        anomaly_score = distance.jaccard(user_input.values,Cluster_array[i]) # computing the jaccard distances
        jaccard_distances.append(anomaly_score) 
 
    anom_freq_score = []
    centroid_values = clusters_3.values
    Scaled_normal_array = Anom_data

    for j in range(clusters_3.shape[0]):
        score = distance.sqeuclidean(centroid_values[j],Scaled_normal_array)
        anom_freq_score.append(score)

    scores = np.asarray(jaccard_distances) # converting to numpy array
    # scores_freq = np.asarray(anom_freq_score)

    # We obtain the minimum vaue of jaccard distance to see which is the closest/nearest cluster it could belong to
    anomaly_val = np.amin(scores) 
    freq_val = np.amin(anom_freq_score)
    return anomaly_val, freq_val


def decision(inputs):
    message_input = 'Messages_{}'.format(inputs[2])
    protocol_input = 'Protocol_{}'.format(inputs[3])# obtaining in list format
    IP_Value = inputs[0:2] 
    IP_extraction = []

    # Obtaining the binary representation of the ip addresses
    for i in IP_Value:
        ip = ''.join([bin(int(x)+256)[3:] for x in i.split('.')])
        IP_extraction.append(ip)

    dict_IP_all = dict(zip(IP_Value, IP_extraction))

    #creating dataframe for messages and protocol
    columns = list(Clusters.columns[-12:,]) # obtaining the list of columns to be the keys
    listofzeros = [0]*len(columns) # assigning zeros to be the values for all the messages and protocols
    msgs_protocol = dict(zip(columns,listofzeros)) # creating a dictionary 
    msgs_protocol[message_input] = 1 # changing the value of whatever message that was input to be 1 
    msgs_protocol[protocol_input] = 1  # changing the value of whatever protocol that was input to be 1 
    msgAndProtocol_df = pd.DataFrame(msgs_protocol,index = [0])

    user_val = pd.DataFrame([dict_IP_all[inputs[0]]]) # creating a dataframe for the source
    user_val2 = pd.DataFrame([dict_IP_all[inputs[1]]]) # creating a dataframe for the destination
    user_val = user_val.rename(columns={0: 'IP'})
    user_val2 = user_val2.rename(columns={0: 'dest'})

    # creating dataframe for source ip to be bit1,bit2....bit32
    user_val = user_val['IP'].apply(lambda x: pd.Series(list(x)))
    a1 = user_val.columns[np.arange(0,32)]
    a2 = ['bit' + str(i) for i in np.arange(1,len(a1)+1)]
    a3 = dict(zip(a1, a2))
    user_val = user_val.rename(columns=a3)
    user_val = user_val.astype(int)

    # creating dataframe for source ip to be bit33,bit32....bit64
    user_val2 = user_val2['dest'].apply(lambda y: pd.Series(list(y)))
    b1 = user_val2.columns[np.arange(0,32)]
    b2 = ['bit' + str(i) for i in np.arange(33,len(b1)+33)]
    b3 = dict(zip(b1, b2))
    user_val2 = user_val2.rename(columns=b3)    
    user_val2 = user_val2.astype(int)
    
    user_input = pd.concat([user_val, user_val2,msgAndProtocol_df], axis=1)
    check_anomaly,freq_anomaly = anomaly_values(user_input,inputs)

    # check if the anomaly score is greater than the threshold
    # if it is then we assign the boolean to be true that the input was an anomaly
    bms_output = 0
    if check_anomaly > 0.45:
        bms_output = 1

    freq_output = 1
    if freq_anomaly>25.21:
        freq_output = 1

    return bms_output, check_anomaly,freq_anomaly, freq_output

        
# This function is to test the inputs
def test_function(entry):
    # myLabel = tk.Label(root, )
    inputs = []
    for x in entry:
        # print(x.get())
        inputs.append(str(x.get()))

    print(inputs[4],type(inputs[4]))

    output = 'Your inputs are: \n{0} | {1} | {2} | {3}\n'.format(inputs[0],inputs[1],inputs[2],inputs[3])
# if there is no frequency involved then it would undergo the kmodes detection algorithm
    checking_val = decision(inputs[0:4])
    if checking_val[0] == 1  or checking_val[3] == 1:
        test_output = 'an anomaly'
    else:
        test_output = 'Not an anomaly'
    
    
    label_o['text'] = '{0}\nYour input is {1} with a score of {2} \nfor a frequency input of {3} and score of {4}'.format(output, test_output,checking_val[1],inputs[4],checking_val[2])
    
    # if checking_val[3] == 1:
    #     freq_output = 'an anomaly'
    # else:
    #     freq_output = 'Not an anomaly'
    # if the frequency is involved like DDOS attacks then kmeans will be used. 

    # label_o['text'] = '{0}\nYour input is {1} for frequency input of {2}'.format(output,freq_output,inputs[4])
    # print("This is the entry:", entry)


canvas = tk.Canvas(root,height = HEIGHT, width = WIDTH) #create size of window 
canvas.pack()


path = 'D:\\Python\\Ideas\\black_background.png'
background_image = tk.PhotoImage(file = path)
background_label = tk.Label(root, image = background_image)
background_label.place(x= 0,y=0, relwidth = 1, relheight = 1)

# creating frame for all the user inputs so that it can have an entry and a label
frame_S = tk.Frame(root, bg = '#80b3ff', bd = 4) 
frame_S.place(relx = 0.5, rely = 0.02, relwidth = 0.9, relheight = 0.08,anchor = 'n') 

label = tk.Label(frame_S, text = 'Source', font = ('Ink Free', 18), anchor = 'w') 
#increasing the font size doesnt make much of a difference so importing font from tkinter
label.place(relx = 0, rely = 0, relwidth = 0.3, relheight = 1)
# label.pack(side = tk.LEFT)

entry1 = tk.Entry(frame_S,font = ('Ink Free', 20))
entry1.place(relx = 0.2, rely = 0, relwidth = 0.8, relheight = 1)
# entry1.pack(side = tk.RIGHT)


frame_D = tk.Frame(root, bg = '#80b3ff', bd = 4) 
frame_D.place(relx = 0.5, rely = 0.12, relwidth = 0.9, relheight = 0.08,anchor = 'n') 

label2 = tk.Label(frame_D, text = 'Destination', font = ('Ink Free', 18), anchor = 'w') 
#increasing the font size doesnt make much of a difference so importing font from tkinter
label2.place(relx = 0, rely = 0, relwidth = 1, relheight = 1)

entry2 = tk.Entry(frame_D,font = ('Ink Free', 20))
entry2.place(relx = 0.2, rely = 0, relwidth = 0.8, relheight = 1)


frame_M = tk.Frame(root, bg = '#80b3ff', bd = 4) 
frame_M.place(relx = 0.5, rely = 0.22, relwidth = 0.9, relheight = 0.08,anchor = 'n') 

label3 = tk.Label(frame_M, text = 'Message', font = ('Ink Free', 18), anchor = 'w') #increasing the font size doesnt make much of a difference so importing font from tkinter
label3.place(relx = 0, rely = 0, relwidth = 1, relheight = 1)

entry3 = tk.Entry(frame_M,font = ('Ink Free', 20))
entry3.place(relx = 0.2, rely = 0,relwidth = 0.8, relheight = 1)


frame_P = tk.Frame(root, bg = '#80b3ff', bd = 4) 
frame_P.place(relx = 0.5, rely = 0.32, relwidth = 0.9, relheight = 0.08,anchor = 'n') 

label3 = tk.Label(frame_P, text = 'Protocol', font = ('Ink Free', 18), anchor = 'w') #increasing the font size doesnt make much of a difference so importing font from tkinter
label3.place(relx = 0, rely = 0, relwidth = 1, relheight = 1)

entry4 = tk.Entry(frame_P,font = ('Ink Free', 20))
entry4.place(relx = 0.2, rely = 0,relwidth = 0.8, relheight = 1)


frame_F = tk.Frame(root, bg = '#80b3ff', bd = 4) 
frame_F.place(relx = 0.5, rely = 0.43, relwidth = 0.9, relheight = 0.08,anchor = 'n') 

label4 = tk.Label(frame_F, text = 'Frequency', font = ('Ink Free', 18), anchor = 'w') #increasing the font size doesnt make much of a difference so importing font from tkinter
label4.place(relx = 0, rely = 0, relwidth = 1, relheight = 1)

entry5 = tk.Entry(frame_F,font = ('Ink Free', 20))
entry5.place(relx = 0.2, rely = 0,relwidth = 0.8, relheight = 1)


entries = [entry1, entry2, entry3, entry4, entry5]

button_S = tk.Button(root,text = "Enter",bg = '#e6e6ff', fg = 'black', font = ('Ink Free', 18), command =lambda: test_function(entries)) 
#command is the function to be called when the button is clicked and lambda is used to resolve the issue that the function runs ahead of time so it runs once but 
#wont update the entry since it temporarily stored in memory 
#button = tk.Button(root,text = "Test Button",bg = 'gray', fg = 'red')#,fg = "red")place button inside the root(which contains everything) 
#button.pack(side = 'left', fill = 'x', expand = True) #packs the button widget in the root window, look at documentation to see keyword arguments
#button.grid(row = 0, column = 0)
button_S.place(relx = 0.38, rely = 0.52, relwidth = 0.3, relheight = 0.08) 


left_frame = tk.Frame(root,bg = '#80b3ff', bd = 6)
# left_frame.place(relx = 0.4, rely = 0.70, relwidth = 0.65, relheight = 0.55, anchor = 'n') #the output box
left_frame.place(x = 50, y = 380, height = 200, width = 600)

label_o = tk.Label(left_frame, bg = '#f3f5f0', font = ('Ink Free', 15), anchor = 'nw', justify = 'left') #increasing the font size doesnt make much of a difference so importing font from tkinter
label_o.place(relwidth = 1, relheight = 1)
#f3f5f0
#e6ffff
root.mainloop()